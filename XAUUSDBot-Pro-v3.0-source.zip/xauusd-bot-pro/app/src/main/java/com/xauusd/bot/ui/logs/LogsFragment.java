package com.xauusd.bot.ui.logs;

import android.os.Bundle;
import android.view.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.xauusd.bot.databinding.FragmentLogsBinding;

public class LogsFragment extends Fragment {

    private FragmentLogsBinding binding;
    private LogsViewModel viewModel;
    private TradeLogAdapter adapter;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentLogsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(LogsViewModel.class);

        adapter = new TradeLogAdapter();
        binding.recyclerLogs.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerLogs.setAdapter(adapter);

        viewModel.getLogs().observe(getViewLifecycleOwner(), logs -> {
            adapter.submitList(logs);
            binding.tvNoLogs.setVisibility(logs == null || logs.isEmpty() ? View.VISIBLE : View.GONE);
        });

        binding.btnClearLogs.setOnClickListener(v -> viewModel.clearLogs());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
