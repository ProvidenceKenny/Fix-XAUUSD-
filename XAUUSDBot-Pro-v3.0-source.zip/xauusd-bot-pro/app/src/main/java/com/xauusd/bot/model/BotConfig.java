package com.xauusd.bot.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.Ignore;

@Entity(tableName = "bots")
public class BotConfig {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String name;
    public String brokerName;
    public String brokerUrl;
    public String mtType;
    public String mtLogin;
    public String mtPass;
    public String mtServer;
    public int mode;
    public double lot;
    public boolean active;
    public long createdAt;

    public BotConfig() {
        this.createdAt = System.currentTimeMillis();
        this.active = false;
        this.mode = 1;
        this.lot = 0.01;
        this.mtType = "MT5";
    }

    @Ignore
    public BotConfig(String name, String brokerName, String brokerUrl,
                     String mtType, String mtLogin, String mtPass,
                     String mtServer, int mode, double lot) {
        this.name = name;
        this.brokerName = brokerName;
        this.brokerUrl = brokerUrl;
        this.mtType = mtType;
        this.mtLogin = mtLogin;
        this.mtPass = mtPass;
        this.mtServer = mtServer;
        this.mode = mode;
        this.lot = lot;
        this.active = false;
        this.createdAt = System.currentTimeMillis();
    }
}
