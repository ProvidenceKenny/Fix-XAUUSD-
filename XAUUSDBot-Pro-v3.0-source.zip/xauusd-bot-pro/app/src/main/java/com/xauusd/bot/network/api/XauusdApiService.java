package com.xauusd.bot.network.api;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface XauusdApiService {
    @GET("v8/finance/chart/GC%3DF")
    Call<YahooFinanceResponse> getGoldChart(
            @Query("interval") String interval,
            @Query("range")    String range
    );
}
