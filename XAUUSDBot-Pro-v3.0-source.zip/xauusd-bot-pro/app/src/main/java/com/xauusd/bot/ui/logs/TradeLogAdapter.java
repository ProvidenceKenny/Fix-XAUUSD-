package com.xauusd.bot.ui.logs;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.xauusd.bot.R;
import com.xauusd.bot.model.TradeLog;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TradeLogAdapter extends ListAdapter<TradeLog, TradeLogAdapter.LogViewHolder> {

    private static final SimpleDateFormat SDF = new SimpleDateFormat("MM/dd HH:mm:ss", Locale.getDefault());

    public TradeLogAdapter() { super(DIFF); }

    @NonNull @Override
    public LogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_log, parent, false);
        return new LogViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull LogViewHolder h, int position) {
        TradeLog log = getItem(position);
        h.tvTime.setText(SDF.format(new Date(log.timestamp)));
        h.tvBot.setText(log.botName);
        h.tvAction.setText(log.action);
        h.tvAction.setTextColor("BUY".equalsIgnoreCase(log.action) ? 0xFF4CAF50 : 0xFFFF5722);
        h.tvLot.setText("Lot: " + log.lot);
        h.tvResult.setText(log.result);
    }

    static class LogViewHolder extends RecyclerView.ViewHolder {
        TextView tvTime, tvBot, tvAction, tvLot, tvResult;
        LogViewHolder(View v) {
            super(v);
            tvTime   = v.findViewById(R.id.tv_log_time);
            tvBot    = v.findViewById(R.id.tv_log_bot);
            tvAction = v.findViewById(R.id.tv_log_action);
            tvLot    = v.findViewById(R.id.tv_log_lot);
            tvResult = v.findViewById(R.id.tv_log_result);
        }
    }

    private static final DiffUtil.ItemCallback<TradeLog> DIFF = new DiffUtil.ItemCallback<TradeLog>() {
        @Override public boolean areItemsTheSame(@NonNull TradeLog a, @NonNull TradeLog b) { return a.id == b.id; }
        @Override public boolean areContentsTheSame(@NonNull TradeLog a, @NonNull TradeLog b) { return a.result.equals(b.result); }
    };
}
