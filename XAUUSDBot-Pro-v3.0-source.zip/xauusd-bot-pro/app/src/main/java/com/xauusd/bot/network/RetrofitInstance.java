package com.xauusd.bot.network;

import com.xauusd.bot.network.api.XauusdApiService;
import com.xauusd.bot.utils.Constants;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import java.util.concurrent.TimeUnit;

public class RetrofitInstance {
    private static RetrofitInstance instance;
    private final XauusdApiService apiService;

    private RetrofitInstance() {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BASIC);

        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .addInterceptor(chain -> {
                    Request original = chain.request();
                    Request withAgent = original.newBuilder()
                            .header("User-Agent",
                                    "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36")
                            .header("Accept", "application/json")
                            .build();
                    return chain.proceed(withAgent);
                })
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        apiService = retrofit.create(XauusdApiService.class);
    }

    public static synchronized RetrofitInstance getInstance() {
        if (instance == null) instance = new RetrofitInstance();
        return instance;
    }

    public XauusdApiService getApiService() { return apiService; }
}
