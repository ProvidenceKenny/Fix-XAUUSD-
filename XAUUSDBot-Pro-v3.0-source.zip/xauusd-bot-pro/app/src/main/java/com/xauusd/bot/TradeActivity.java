package com.xauusd.bot;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.*;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.xauusd.bot.db.AppDatabase;
import com.xauusd.bot.model.TradeLog;
import com.xauusd.bot.utils.Constants;
import java.util.concurrent.Executors;

public class TradeActivity extends AppCompatActivity {

    private static final String TAG = "TradeActivity";

    private WebView webView;
    private TextView tvStatus;

    private String brokerUrl, mtLogin, mtPass, mtServer, mtType, signalAction, botName;
    private double signalLot, signalSl, signalTp;
    private int botId;
    private boolean tradeExecuted = false;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trade);

        webView  = findViewById(R.id.trade_webview);
        tvStatus = findViewById(R.id.tv_trade_status);

        Intent intent = getIntent();
        brokerUrl    = intent.getStringExtra("broker_url");
        mtLogin      = intent.getStringExtra("mt_login");
        mtPass       = intent.getStringExtra("mt_pass");
        mtServer     = intent.getStringExtra("mt_server");
        mtType       = intent.getStringExtra("mt_type");
        signalAction = intent.getStringExtra("signal_action");
        signalLot    = intent.getDoubleExtra("signal_lot", Constants.LOT_NORMAL);
        signalSl     = intent.getDoubleExtra("signal_sl", 0);
        signalTp     = intent.getDoubleExtra("signal_tp", 0);
        botId        = intent.getIntExtra("bot_id", -1);
        botName      = intent.getStringExtra("bot_name");

        if (brokerUrl == null || brokerUrl.isEmpty()) {
            tvStatus.setText("❌ No broker URL configured");
            finishAfterDelay(3000);
            return;
        }

        tvStatus.setText("🔗 Connecting to broker...");
        setupWebView();
        loadBrokerTerminal();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36");

        webView.addJavascriptInterface(new JsBridge(), "XAUUSDBot");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                tvStatus.setText("📄 Terminal loaded — preparing trade...");
                new Handler(Looper.getMainLooper()).postDelayed(() -> injectCredentials(), 4000);
            }
        });
    }

    private void loadBrokerTerminal() {
        String url = brokerUrl;
        if (!"MT4".equals(mtType)) {
            url += (url.contains("?") ? "&" : "?");
            if (mtServer != null && !mtServer.isEmpty()) url += "server=" + mtServer + "&";
            if (mtLogin  != null && !mtLogin.isEmpty())  url += "login=" + mtLogin;
        }
        webView.loadUrl(url);
    }

    private void injectCredentials() {
        if (tradeExecuted) return;
        if (mtLogin != null && !mtLogin.isEmpty() && mtPass != null && !mtPass.isEmpty()) {
            String loginJs =
                "(function(){try{" +
                "var li=document.querySelectorAll('input[type=\"text\"],input[name=\"login\"]');" +
                "var pi=document.querySelectorAll('input[type=\"password\"],input[name=\"password\"]');" +
                "if(li.length>0)li[0].value='" + mtLogin + "';" +
                "if(pi.length>0)pi[0].value='" + mtPass + "';" +
                "var btns=document.querySelectorAll('button,input[type=\"submit\"]');" +
                "for(var i=0;i<btns.length;i++){" +
                "  var t=btns[i].textContent||btns[i].value;" +
                "  if(t&&(t.toLowerCase().includes('login')||t.toLowerCase().includes('connect'))){btns[i].click();break;}" +
                "}" +
                "XAUUSDBot.onResult('Credentials filled');" +
                "}catch(e){XAUUSDBot.onResult('Login error: '+e.message);}})();";
            webView.evaluateJavascript(loginJs, null);
            new Handler(Looper.getMainLooper()).postDelayed(this::executeTrade, 3000);
        } else {
            executeTrade();
        }
    }

    private void executeTrade() {
        if (tradeExecuted) return;
        tradeExecuted = true;

        String action  = "BUY".equalsIgnoreCase(signalAction) ? "Buy" : "Sell";
        String tradeJs = Constants.buildTradeJS(action, signalLot, signalSl, signalTp);

        tvStatus.setText("⚡ Executing " + signalAction + " XAUUSD × " + signalLot + "...");
        webView.evaluateJavascript(tradeJs, value -> {
            Log.d(TAG, "Trade JS: " + value);
            runOnUiThread(() -> tvStatus.setText("✅ " + signalAction + " order sent — lot: " + signalLot));
        });

        if ("MT4".equals(mtType)) {
            webView.loadUrl("javascript:ChartTrade" + action + "(0," + signalLot + ",''," + signalSl + "," + signalTp + ");");
        }

        saveLog("✅ Executed");
        finishAfterDelay(5000);
    }

    private void saveLog(String result) {
        Executors.newSingleThreadExecutor().execute(() -> {
            TradeLog log = new TradeLog();
            log.botId   = botId;
            log.botName = botName != null ? botName : "Bot";
            log.action  = signalAction;
            log.lot     = signalLot;
            log.sl      = signalSl;
            log.tp      = signalTp;
            log.result  = result;
            AppDatabase.getInstance(this).tradeLogDao().insert(log);
        });
    }

    private void finishAfterDelay(long ms) {
        new Handler(Looper.getMainLooper()).postDelayed(this::finish, ms);
    }

    public class JsBridge {
        @JavascriptInterface
        public void onResult(String result) {
            Log.d(TAG, "JS Bridge: " + result);
            runOnUiThread(() -> tvStatus.setText("🔑 " + result));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (webView != null) webView.destroy();
    }
}
