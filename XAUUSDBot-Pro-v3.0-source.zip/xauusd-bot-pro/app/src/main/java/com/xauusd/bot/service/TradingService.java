package com.xauusd.bot.service;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.*;
import android.util.Log;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import com.xauusd.bot.MainActivity;
import com.xauusd.bot.R;
import com.xauusd.bot.TradeActivity;
import com.xauusd.bot.db.AppDatabase;
import com.xauusd.bot.model.BotConfig;
import com.xauusd.bot.network.RetrofitInstance;
import com.xauusd.bot.network.api.XauusdApiService;
import com.xauusd.bot.network.api.YahooFinanceResponse;
import com.xauusd.bot.utils.SignalEngine;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import java.util.List;
import java.util.concurrent.Executors;

public class TradingService extends Service {

    private static final String TAG        = "TradingService";
    private static final String CHANNEL_ID = "XAUUSDBot";
    private static final int    NOTIF_ID   = 1001;
    private static final long   POLL_MS    = 30_000;

    private WindowManager windowManager;
    private View overlayView;
    private WindowManager.LayoutParams overlayParams;
    private boolean overlayCreated = false;

    private final Handler pollHandler = new Handler(Looper.getMainLooper());
    private XauusdApiService apiService;
    private boolean running = false;
    private boolean busy    = false;

    private int   initialX, initialY;
    private float initialTouchX, initialTouchY;

    private final Runnable pollRunnable = new Runnable() {
        @Override public void run() {
            if (running) {
                fetchGoldData();
                pollHandler.postDelayed(this, POLL_MS);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        apiService = RetrofitInstance.getInstance().getApiService();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());
        createOverlay();
        running = true;
        pollHandler.post(pollRunnable);
        Log.d(TAG, "TradingService started — Yahoo Finance / SMA crossover");
        return START_STICKY;
    }

    private void fetchGoldData() {
        if (!isNetworkAvailable()) { updateStatus("⚡ No internet"); return; }
        if (busy) return;
        updateStatus("🔍 Fetching gold price...");

        apiService.getGoldChart("5m", "1d").enqueue(new Callback<YahooFinanceResponse>() {
            @Override
            public void onResponse(Call<YahooFinanceResponse> call,
                                   Response<YahooFinanceResponse> response) {
                if (!running) return;
                if (!response.isSuccessful() || response.body() == null) {
                    updateStatus("⚠️ No data from server");
                    return;
                }

                YahooFinanceResponse body = response.body();
                if (body.chart == null
                        || body.chart.result == null
                        || body.chart.result.isEmpty()) {
                    updateStatus("⚠️ Empty chart response");
                    return;
                }

                YahooFinanceResponse.ChartResult result = body.chart.result.get(0);
                double currentPrice = result.meta != null ? result.meta.regularMarketPrice : 0;

                List<Double> closes = null;
                if (result.indicators != null
                        && result.indicators.quote != null
                        && !result.indicators.quote.isEmpty()) {
                    closes = result.indicators.quote.get(0).close;
                }

                SignalEngine.SignalResult sig = SignalEngine.compute(closes, currentPrice);
                Log.d(TAG, "Signal: " + sig.action + " @ " + sig.price + " | " + sig.reason);

                if ("HOLD".equals(sig.action)) {
                    updateStatus("⏳ HOLD  $" + String.format("%.2f", currentPrice));
                } else {
                    updateStatus("📊 " + sig.action + "  $" + String.format("%.2f", currentPrice));
                    dispatchToActiveBots(sig);
                }
            }

            @Override
            public void onFailure(Call<YahooFinanceResponse> call, Throwable t) {
                if (!running) return;
                updateStatus("❌ Network error");
                Log.e(TAG, "Gold fetch failed", t);
            }
        });
    }

    private void dispatchToActiveBots(SignalEngine.SignalResult signal) {
        if (busy) return;
        busy = true;

        Executors.newSingleThreadExecutor().execute(() -> {
            List<BotConfig> activeBots =
                    AppDatabase.getInstance(this).botConfigDao().getActiveBots();
            if (activeBots == null || activeBots.isEmpty()) {
                updateStatus("⏳ No active bots");
                busy = false;
                return;
            }
            BotConfig bot = activeBots.get(0);
            updateStatus("🚀 " + signal.action + " XAUUSD × " + bot.lot);

            Intent intent = new Intent(this, TradeActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("broker_url",    bot.brokerUrl);
            intent.putExtra("mt_login",      bot.mtLogin);
            intent.putExtra("mt_pass",       bot.mtPass);
            intent.putExtra("mt_server",     bot.mtServer);
            intent.putExtra("mt_type",       bot.mtType);
            intent.putExtra("signal_action", signal.action);
            intent.putExtra("signal_lot",    bot.lot);
            intent.putExtra("signal_sl",     signal.sl);
            intent.putExtra("signal_tp",     signal.tp);
            intent.putExtra("bot_id",        bot.id);
            intent.putExtra("bot_name",      bot.name);
            startActivity(intent);

            new Handler(Looper.getMainLooper()).postDelayed(() -> busy = false, 15_000);
        });
    }

    // ─── Overlay ─────────────────────────────────────────────────────────────

    @SuppressWarnings("ClickableViewAccessibility")
    private void createOverlay() {
        if (overlayCreated) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        overlayView = inflater.inflate(R.layout.overlay_trading, null);

        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = 16;
        overlayParams.y = 200;

        overlayView.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = overlayParams.x;  initialY = overlayParams.y;
                    initialTouchX = e.getRawX(); initialTouchY = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    overlayParams.x = initialX + (int)(e.getRawX() - initialTouchX);
                    overlayParams.y = initialY + (int)(e.getRawY() - initialTouchY);
                    windowManager.updateViewLayout(overlayView, overlayParams);
                    return true;
            }
            return false;
        });

        windowManager.addView(overlayView, overlayParams);
        overlayCreated = true;
        updateStatus("🟢 Bot Active");
    }

    private void updateStatus(String status) {
        if (overlayView == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            TextView tv = overlayView.findViewById(R.id.overlay_tv_status);
            if (tv != null) tv.setText(status);
        });
    }

    // ─── Notification ────────────────────────────────────────────────────────

    private void createNotificationChannel() {
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "XAUUSD Bot", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Trading service running in background");
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setOngoing(true)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setContentTitle("XAUUSD Bot Pro — Active")
                .setContentText("Monitoring gold via Yahoo Finance (SMA crossover)")
                .setContentIntent(pi)
                .build();
    }

    // ─── Network ─────────────────────────────────────────────────────────────

    private boolean isNetworkAvailable() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(cm.getActiveNetwork());
        return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        running = false;
        pollHandler.removeCallbacks(pollRunnable);
        if (overlayCreated && overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) {}
            overlayCreated = false;
        }
    }

    @Nullable @Override
    public IBinder onBind(Intent intent) { return null; }
}
