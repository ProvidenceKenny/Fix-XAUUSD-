package com.xauusd.bot.ui.home;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.xauusd.bot.R;
import com.xauusd.bot.model.BotConfig;
import com.xauusd.bot.utils.Constants;

public class BotAdapter extends ListAdapter<BotConfig, BotAdapter.BotViewHolder> {

    public interface BotActionListener {
        void onStart(BotConfig bot);
        void onStop(BotConfig bot);
        void onDelete(BotConfig bot);
    }

    private final BotActionListener listener;

    public BotAdapter(BotActionListener listener) {
        super(DIFF);
        this.listener = listener;
    }

    @NonNull @Override
    public BotViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bot, parent, false);
        return new BotViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull BotViewHolder h, int position) {
        BotConfig bot = getItem(position);
        h.tvName.setText(bot.name);
        h.tvBroker.setText(bot.brokerName != null ? bot.brokerName : "—");
        h.tvMode.setText("Mode: " + Constants.getModeLabel(bot.mode));
        h.tvLot.setText("Lot: " + bot.lot);
        h.tvMtType.setText(bot.mtType != null ? bot.mtType : "MT5");
        h.tvStatus.setText(bot.active ? "● ACTIVE" : "● STOPPED");
        h.tvStatus.setTextColor(bot.active ? 0xFF4CAF50 : 0xFFFF5722);
        h.btnToggle.setText(bot.active ? "STOP" : "START");
        h.btnToggle.setBackgroundColor(bot.active ? 0xFFFF5722 : 0xFF4CAF50);
        h.btnToggle.setOnClickListener(v -> {
            if (bot.active) listener.onStop(bot);
            else            listener.onStart(bot);
        });
        h.btnDelete.setOnClickListener(v -> listener.onDelete(bot));
    }

    static class BotViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvBroker, tvMode, tvLot, tvMtType, tvStatus;
        Button   btnToggle, btnDelete;
        BotViewHolder(View v) {
            super(v);
            tvName   = v.findViewById(R.id.tv_bot_name);
            tvBroker = v.findViewById(R.id.tv_bot_broker);
            tvMode   = v.findViewById(R.id.tv_bot_mode);
            tvLot    = v.findViewById(R.id.tv_bot_lot);
            tvMtType = v.findViewById(R.id.tv_bot_mt_type);
            tvStatus = v.findViewById(R.id.tv_bot_status);
            btnToggle = v.findViewById(R.id.btn_bot_toggle);
            btnDelete = v.findViewById(R.id.btn_bot_delete);
        }
    }

    private static final DiffUtil.ItemCallback<BotConfig> DIFF = new DiffUtil.ItemCallback<BotConfig>() {
        @Override public boolean areItemsTheSame(@NonNull BotConfig a, @NonNull BotConfig b) { return a.id == b.id; }
        @Override public boolean areContentsTheSame(@NonNull BotConfig a, @NonNull BotConfig b) {
            return a.active == b.active && a.name.equals(b.name) && a.mode == b.mode;
        }
    };
}
