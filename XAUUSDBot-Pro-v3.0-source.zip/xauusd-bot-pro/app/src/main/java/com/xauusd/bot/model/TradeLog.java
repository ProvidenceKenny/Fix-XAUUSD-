package com.xauusd.bot.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "trade_logs")
public class TradeLog {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public int botId;
    public String botName;
    public String action;
    public double lot;
    public double sl;
    public double tp;
    public String result;
    public long timestamp;

    public TradeLog() {
        this.timestamp = System.currentTimeMillis();
    }
}
