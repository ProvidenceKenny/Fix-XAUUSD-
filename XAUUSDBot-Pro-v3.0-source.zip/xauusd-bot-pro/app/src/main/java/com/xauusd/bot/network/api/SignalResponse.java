package com.xauusd.bot.network.api;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class SignalResponse {
    @SerializedName("success") private boolean success;
    @SerializedName("signals") private List<Signal> signals;

    public boolean isSuccess()        { return success; }
    public List<Signal> getSignals()  { return signals; }
}
