package com.xauusd.bot.ui.home;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.xauusd.bot.db.AppDatabase;
import com.xauusd.bot.db.BotConfigDao;
import com.xauusd.bot.model.BotConfig;
import java.util.List;
import java.util.concurrent.Executors;

public class HomeViewModel extends AndroidViewModel {

    private final BotConfigDao dao;
    private final LiveData<List<BotConfig>> bots;

    public HomeViewModel(Application app) {
        super(app);
        dao  = AppDatabase.getInstance(app).botConfigDao();
        bots = dao.getAll();
    }

    public LiveData<List<BotConfig>> getBots() { return bots; }

    public void insert(BotConfig bot) {
        Executors.newSingleThreadExecutor().execute(() -> dao.insert(bot));
    }

    public void delete(BotConfig bot) {
        Executors.newSingleThreadExecutor().execute(() -> dao.delete(bot));
    }

    public void setActive(int id, boolean active) {
        Executors.newSingleThreadExecutor().execute(() -> dao.setActive(id, active));
    }
}
