package com.xauusd.bot.utils;

import java.util.ArrayList;
import java.util.List;

public class SignalEngine {

    private static final int SMA_FAST = 10;
    private static final int SMA_SLOW = 20;
    private static final double SL_PIPS = 5.0;
    private static final double TP_PIPS = 10.0;
    private static final double THRESHOLD = 0.0003;

    public static class SignalResult {
        public final String action;
        public final double price;
        public final double sl;
        public final double tp;
        public final String reason;

        SignalResult(String action, double price, double sl, double tp, String reason) {
            this.action = action;
            this.price  = price;
            this.sl     = sl;
            this.tp     = tp;
            this.reason = reason;
        }
    }

    public static SignalResult compute(List<Double> rawCloses, double currentPrice) {
        List<Double> closes = filterNulls(rawCloses);
        if (closes.size() < SMA_SLOW) {
            return new SignalResult("HOLD", currentPrice,
                    currentPrice - SL_PIPS, currentPrice + TP_PIPS,
                    "Not enough data (" + closes.size() + "/" + SMA_SLOW + " candles)");
        }

        double smaFast = sma(closes, SMA_FAST);
        double smaSlow = sma(closes, SMA_SLOW);
        double ratio   = (smaFast - smaSlow) / smaSlow;

        String action;
        double sl, tp;
        String reason;

        if (ratio > THRESHOLD) {
            action = "BUY";
            sl     = currentPrice - SL_PIPS;
            tp     = currentPrice + TP_PIPS;
            reason = String.format("SMA%d(%.2f) > SMA%d(%.2f)", SMA_FAST, smaFast, SMA_SLOW, smaSlow);
        } else if (ratio < -THRESHOLD) {
            action = "SELL";
            sl     = currentPrice + SL_PIPS;
            tp     = currentPrice - TP_PIPS;
            reason = String.format("SMA%d(%.2f) < SMA%d(%.2f)", SMA_FAST, smaFast, SMA_SLOW, smaSlow);
        } else {
            action = "HOLD";
            sl     = currentPrice - SL_PIPS;
            tp     = currentPrice + TP_PIPS;
            reason = String.format("SMA%d ≈ SMA%d (flat)", SMA_FAST, SMA_SLOW);
        }

        return new SignalResult(action, currentPrice, sl, tp, reason);
    }

    private static double sma(List<Double> list, int period) {
        int start = list.size() - period;
        double sum = 0;
        for (int i = start; i < list.size(); i++) sum += list.get(i);
        return sum / period;
    }

    private static List<Double> filterNulls(List<Double> input) {
        List<Double> out = new ArrayList<>();
        if (input == null) return out;
        for (Double d : input) {
            if (d != null && d > 0) out.add(d);
        }
        return out;
    }
}
