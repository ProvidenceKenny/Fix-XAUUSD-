package com.xauusd.bot.db;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.xauusd.bot.model.TradeLog;
import java.util.List;

@Dao
public interface TradeLogDao {
    @Query("SELECT * FROM trade_logs ORDER BY timestamp DESC LIMIT 200")
    LiveData<List<TradeLog>> getAll();

    @Insert
    void insert(TradeLog log);

    @Query("DELETE FROM trade_logs")
    void clearAll();
}
