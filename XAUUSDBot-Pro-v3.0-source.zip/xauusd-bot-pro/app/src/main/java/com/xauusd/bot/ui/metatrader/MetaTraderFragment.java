package com.xauusd.bot.ui.metatrader;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;
import com.xauusd.bot.R;
import com.xauusd.bot.utils.Constants;
import java.util.ArrayList;
import java.util.List;

public class MetaTraderFragment extends Fragment {

    private TextInputEditText etLogin, etPass, etServer, etCustomUrl;
    private Spinner spinBroker;
    private TabLayout tabLayout;
    private SharedPreferences prefs;
    private String currentMtType = "MT5";

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_metatrader, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        prefs = requireContext().getSharedPreferences(Constants.PREFS_SETTINGS, 0);

        etLogin    = view.findViewById(R.id.et_login);
        etPass     = view.findViewById(R.id.et_password);
        etServer   = view.findViewById(R.id.et_server);
        etCustomUrl = view.findViewById(R.id.et_custom_broker_url);
        spinBroker = view.findViewById(R.id.spin_broker_mt);
        tabLayout  = view.findViewById(R.id.tab_mt_type);
        View layoutCustom = view.findViewById(R.id.layout_custom_broker);

        // MT type tabs
        tabLayout.addTab(tabLayout.newTab().setText("MT4"));
        tabLayout.addTab(tabLayout.newTab().setText("MT5"));
        tabLayout.selectTab(tabLayout.getTabAt(1)); // default MT5
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab tab) {
                currentMtType = tab.getText() != null ? tab.getText().toString() : "MT5";
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        // Broker spinner
        List<String> brokerNames = new ArrayList<>(Constants.BROKER_URLS.keySet());
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_item, brokerNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinBroker.setAdapter(adapter);
        spinBroker.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v2, int pos, long id) {
                layoutCustom.setVisibility(brokerNames.get(pos).equals("Custom URL") ? View.VISIBLE : View.GONE);
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        // Load saved values
        etLogin.setText(prefs.getString(Constants.KEY_MT_LOGIN, ""));
        etPass.setText(prefs.getString(Constants.KEY_MT_PASS, ""));
        etServer.setText(prefs.getString(Constants.KEY_MT_SERVER, ""));
        String savedType = prefs.getString(Constants.KEY_MT_TYPE, "MT5");
        tabLayout.selectTab(tabLayout.getTabAt("MT4".equals(savedType) ? 0 : 1));

        // Status card
        updateStatusCard(view);

        // Save button
        view.findViewById(R.id.btn_save_mt).setOnClickListener(v -> {
            String login  = etLogin.getText()  != null ? etLogin.getText().toString().trim()  : "";
            String pass   = etPass.getText()   != null ? etPass.getText().toString().trim()   : "";
            String server = etServer.getText() != null ? etServer.getText().toString().trim() : "";
            String brokerName = brokerNames.get(spinBroker.getSelectedItemPosition());
            String brokerUrl  = Constants.BROKER_URLS.get(brokerName);
            if ("Custom URL".equals(brokerName) && etCustomUrl.getText() != null) {
                brokerUrl = etCustomUrl.getText().toString().trim();
            }

            prefs.edit()
                    .putString(Constants.KEY_MT_LOGIN,  login)
                    .putString(Constants.KEY_MT_PASS,   pass)
                    .putString(Constants.KEY_MT_SERVER, server)
                    .putString(Constants.KEY_MT_TYPE,   currentMtType)
                    .putString(Constants.KEY_BROKER_URL, brokerUrl)
                    .apply();
            Toast.makeText(requireContext(), "✅ Account saved!", Toast.LENGTH_SHORT).show();
            updateStatusCard(view);
        });
    }

    private void updateStatusCard(View view) {
        TextView tvConnected = view.findViewById(R.id.tv_connected_status);
        String login = prefs.getString(Constants.KEY_MT_LOGIN, "");
        if (!login.isEmpty()) {
            tvConnected.setText("✅ Account: " + login + " (" + prefs.getString(Constants.KEY_MT_TYPE, "MT5") + ")");
            tvConnected.setTextColor(0xFF4CAF50);
        } else {
            tvConnected.setText("⚪ No account linked");
            tvConnected.setTextColor(0xFF9E9E9E);
        }
    }
}
