package com.xauusd.bot.utils;

import java.util.LinkedHashMap;
import java.util.Map;

public class Constants {

    public static final String BASE_URL = "https://query1.finance.yahoo.com/";

    public static final int MODE_NORMAL     = 1;
    public static final int MODE_ATTACK     = 2;
    public static final int MODE_AGGRESSIVE = 3;

    public static final double LOT_NORMAL     = 0.01;
    public static final double LOT_ATTACK     = 0.05;
    public static final double LOT_AGGRESSIVE = 0.10;

    public static final String PREFS_SETTINGS = "xauusd_settings";
    public static final String KEY_MT_LOGIN   = "mt_login";
    public static final String KEY_MT_PASS    = "mt_pass";
    public static final String KEY_MT_SERVER  = "mt_server";
    public static final String KEY_MT_TYPE    = "mt_type";
    public static final String KEY_BROKER_URL = "broker_url";

    public static final Map<String, String> BROKER_URLS = new LinkedHashMap<String, String>() {{
        put("IC Markets",   "https://www.icmarkets.com/trading/");
        put("Exness",       "https://my.exness.com/a/trading/");
        put("XM",           "https://www.xm.com/mt/");
        put("FxPro",        "https://www.fxpro.com/trading/");
        put("FXTM",         "https://www.forextime.com/trading/");
        put("HFM",          "https://www.hfm.com/trading/");
        put("Hantec",       "https://www.hantecmarkets.com/trading/");
        put("Accumarkets",  "https://www.accumarkets.com/trading/");
        put("RazorMarkets", "https://www.razormarkets.com/trading/");
        put("OpoFinance",   "https://www.opofinance.com/trading/");
        put("Custom URL",   "");
    }};

    public static String getModeLabel(int mode) {
        switch (mode) {
            case MODE_ATTACK:     return "Attack";
            case MODE_AGGRESSIVE: return "Aggressive";
            default:              return "Normal";
        }
    }

    public static double getLotByMode(int mode) {
        switch (mode) {
            case MODE_ATTACK:     return LOT_ATTACK;
            case MODE_AGGRESSIVE: return LOT_AGGRESSIVE;
            default:              return LOT_NORMAL;
        }
    }

    public static String buildTradeJS(String action, double lot, double sl, double tp) {
        return String.format(
            "javascript:(function(){" +
            "try{" +
            "var t=window.terminal||window.MetaTrader||window.mt;" +
            "if(t&&t.Trade){" +
            "t.Trade.%s('XAUUSD',%s,%s,%s);" +
            "}else{" +
            "document.dispatchEvent(new CustomEvent('xauusd_bot_trade',{detail:{action:'%s',lot:%s,sl:%s,tp:%s}}));" +
            "}" +
            "}catch(e){console.error('XAUUSD BOT:'+e);}" +
            "})();",
            action, lot, sl, tp, action, lot, sl, tp
        );
    }
}
