package com.xauusd.bot.ui.logs;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.xauusd.bot.db.AppDatabase;
import com.xauusd.bot.db.TradeLogDao;
import com.xauusd.bot.model.TradeLog;
import java.util.List;
import java.util.concurrent.Executors;

public class LogsViewModel extends AndroidViewModel {

    private final TradeLogDao dao;
    private final LiveData<List<TradeLog>> logs;

    public LogsViewModel(Application app) {
        super(app);
        dao  = AppDatabase.getInstance(app).tradeLogDao();
        logs = dao.getAll();
    }

    public LiveData<List<TradeLog>> getLogs() { return logs; }

    public void clearLogs() {
        Executors.newSingleThreadExecutor().execute(dao::clearAll);
    }
}
