package com.xauusd.bot.db;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.xauusd.bot.model.BotConfig;
import java.util.List;

@Dao
public interface BotConfigDao {
    @Query("SELECT * FROM bots ORDER BY createdAt DESC")
    LiveData<List<BotConfig>> getAll();

    @Query("SELECT * FROM bots WHERE active = 1")
    List<BotConfig> getActiveBots();

    @Query("SELECT * FROM bots WHERE id = :id")
    BotConfig getById(int id);

    @Insert
    long insert(BotConfig bot);

    @Update
    void update(BotConfig bot);

    @Delete
    void delete(BotConfig bot);

    @Query("UPDATE bots SET active = :active WHERE id = :id")
    void setActive(int id, boolean active);

    @Query("UPDATE bots SET active = 0")
    void stopAll();
}
