package com.xauusd.bot.network.api;

import com.google.gson.annotations.SerializedName;

public class Signal {
    @SerializedName("asset")  private String asset;
    @SerializedName("action") private String action;
    @SerializedName("sl")     private double sl;
    @SerializedName("tp")     private double tp;
    @SerializedName("price")  private double price;

    public String getAsset()  { return asset; }
    public String getAction() { return action; }
    public double getSl()     { return sl; }
    public double getTp()     { return tp; }
    public double getPrice()  { return price; }
}
