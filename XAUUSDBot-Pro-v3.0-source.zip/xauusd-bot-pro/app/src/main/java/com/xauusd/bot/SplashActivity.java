package com.xauusd.bot;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

@SuppressLint("CustomSplashScreen")
public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        TextView tvLogo   = findViewById(R.id.tv_splash_logo);
        TextView tvSub    = findViewById(R.id.tv_splash_subtitle);
        TextView tvVersion = findViewById(R.id.tv_splash_version);

        ScaleAnimation scale = new ScaleAnimation(
                0.5f, 1f, 0.5f, 1f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f);
        scale.setDuration(600);
        scale.setFillAfter(true);
        tvLogo.startAnimation(scale);

        AlphaAnimation fade = new AlphaAnimation(0f, 1f);
        fade.setDuration(800);
        fade.setStartOffset(400);
        fade.setFillAfter(true);
        tvSub.startAnimation(fade);
        tvVersion.startAnimation(fade);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }, 2000);
    }
}
