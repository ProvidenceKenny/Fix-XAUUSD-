package com.xauusd.bot.network.api;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class YahooFinanceResponse {

    @SerializedName("chart")
    public ChartWrapper chart;

    public static class ChartWrapper {
        @SerializedName("result")
        public List<ChartResult> result;
        @SerializedName("error")
        public Object error;
    }

    public static class ChartResult {
        @SerializedName("meta")
        public Meta meta;
        @SerializedName("indicators")
        public Indicators indicators;
    }

    public static class Meta {
        @SerializedName("regularMarketPrice")
        public double regularMarketPrice;
        @SerializedName("previousClose")
        public double previousClose;
        @SerializedName("currency")
        public String currency;
    }

    public static class Indicators {
        @SerializedName("quote")
        public List<Quote> quote;
    }

    public static class Quote {
        @SerializedName("close")
        public List<Double> close;
    }
}
