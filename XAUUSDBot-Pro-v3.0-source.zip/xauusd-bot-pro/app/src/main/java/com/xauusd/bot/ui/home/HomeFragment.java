package com.xauusd.bot.ui.home;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.xauusd.bot.databinding.FragmentHomeBinding;
import com.xauusd.bot.model.BotConfig;
import com.xauusd.bot.service.TradingService;

public class HomeFragment extends Fragment implements BotAdapter.BotActionListener {

    private FragmentHomeBinding binding;
    private HomeViewModel viewModel;
    private BotAdapter adapter;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        adapter = new BotAdapter(this);
        binding.recyclerBots.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recyclerBots.setAdapter(adapter);

        viewModel.getBots().observe(getViewLifecycleOwner(), bots -> {
            adapter.submitList(bots);
            binding.tvEmpty.setVisibility(bots == null || bots.isEmpty() ? View.VISIBLE : View.GONE);
            binding.recyclerBots.setVisibility(bots == null || bots.isEmpty() ? View.GONE : View.VISIBLE);
        });

        binding.fabAddBot.setOnClickListener(v -> {
            AddBotDialogFragment dialog = new AddBotDialogFragment();
            dialog.show(getParentFragmentManager(), "AddBot");
        });
    }

    @Override
    public void onStart(BotConfig bot) {
        if (!Settings.canDrawOverlays(requireContext())) {
            new AlertDialog.Builder(requireContext())
                    .setTitle("Overlay Permission Required")
                    .setMessage("XAUUSD Bot needs overlay permission to show status while trading in background.")
                    .setPositiveButton("Grant", (d, w) -> {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + requireContext().getPackageName()));
                        startActivity(intent);
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        viewModel.setActive(bot.id, true);
        Intent svc = new Intent(requireContext(), TradingService.class);
        requireContext().startForegroundService(svc);
        Toast.makeText(requireContext(), "🟢 " + bot.name + " started!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStop(BotConfig bot) {
        viewModel.setActive(bot.id, false);
        requireContext().stopService(new Intent(requireContext(), TradingService.class));
        Toast.makeText(requireContext(), "🔴 " + bot.name + " stopped", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDelete(BotConfig bot) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Delete Bot")
                .setMessage("Remove \"" + bot.name + "\"?")
                .setPositiveButton("Delete", (d, w) -> viewModel.delete(bot))
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
