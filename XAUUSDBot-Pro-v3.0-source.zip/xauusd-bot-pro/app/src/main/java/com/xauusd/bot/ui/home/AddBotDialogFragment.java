package com.xauusd.bot.ui.home;

import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;
import com.google.android.material.textfield.TextInputEditText;
import com.xauusd.bot.R;
import com.xauusd.bot.model.BotConfig;
import com.xauusd.bot.utils.Constants;
import java.util.ArrayList;
import java.util.List;

public class AddBotDialogFragment extends DialogFragment {

    private HomeViewModel viewModel;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NORMAL, R.style.Theme_XAUUSDBot_Dialog);
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_add_bot, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(requireActivity()).get(HomeViewModel.class);

        TextInputEditText etName    = view.findViewById(R.id.et_bot_name);
        TextInputEditText etLogin   = view.findViewById(R.id.et_mt_login);
        TextInputEditText etPass    = view.findViewById(R.id.et_mt_pass);
        TextInputEditText etServer  = view.findViewById(R.id.et_mt_server);
        TextInputEditText etCustom  = view.findViewById(R.id.et_custom_url);
        Spinner           spinBroker= view.findViewById(R.id.spin_broker);
        RadioGroup        rgMtType  = view.findViewById(R.id.rg_mt_type);
        RadioGroup        rgMode    = view.findViewById(R.id.rg_mode);
        Spinner           spinLot   = view.findViewById(R.id.spin_lot);
        View              layoutCustom = view.findViewById(R.id.layout_custom_url);
        Button            btnSave   = view.findViewById(R.id.btn_save_bot);
        Button            btnCancel = view.findViewById(R.id.btn_cancel);

        // Broker spinner
        List<String> brokerNames = new ArrayList<>(Constants.BROKER_URLS.keySet());
        ArrayAdapter<String> brokerAdapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_item, brokerNames);
        brokerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinBroker.setAdapter(brokerAdapter);
        spinBroker.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v2, int pos, long id) {
                boolean isCustom = brokerNames.get(pos).equals("Custom URL");
                layoutCustom.setVisibility(isCustom ? View.VISIBLE : View.GONE);
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });

        // Lot spinner
        String[] lots = {"0.01", "0.02", "0.05", "0.10", "0.20", "0.50", "1.00"};
        ArrayAdapter<String> lotAdapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_item, lots);
        lotAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinLot.setAdapter(lotAdapter);

        btnCancel.setOnClickListener(v -> dismiss());

        btnSave.setOnClickListener(v -> {
            String name = etName.getText() != null ? etName.getText().toString().trim() : "";
            if (name.isEmpty()) { etName.setError("Required"); return; }

            String brokerName = brokerNames.get(spinBroker.getSelectedItemPosition());
            String brokerUrl  = Constants.BROKER_URLS.get(brokerName);
            if ("Custom URL".equals(brokerName)) {
                brokerUrl = etCustom.getText() != null ? etCustom.getText().toString().trim() : "";
                if (brokerUrl.isEmpty()) { etCustom.setError("Enter broker URL"); return; }
            }

            String mtType  = rgMtType.getCheckedRadioButtonId() == R.id.rb_mt4 ? "MT4" : "MT5";
            String login   = etLogin.getText()  != null ? etLogin.getText().toString().trim()  : "";
            String pass    = etPass.getText()   != null ? etPass.getText().toString().trim()   : "";
            String server  = etServer.getText() != null ? etServer.getText().toString().trim() : "";

            int mode = Constants.MODE_NORMAL;
            int modeId = rgMode.getCheckedRadioButtonId();
            if      (modeId == R.id.rb_attack)     mode = Constants.MODE_ATTACK;
            else if (modeId == R.id.rb_aggressive)  mode = Constants.MODE_AGGRESSIVE;

            double lot = Double.parseDouble(lots[spinLot.getSelectedItemPosition()]);

            BotConfig bot = new BotConfig(name, brokerName, brokerUrl, mtType, login, pass, server, mode, lot);
            viewModel.insert(bot);
            dismiss();
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        if (getDialog() != null && getDialog().getWindow() != null) {
            getDialog().getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }
}
