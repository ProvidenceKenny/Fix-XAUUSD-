-keep class com.xauusd.bot.** { *; }
-keep class com.xauusd.bot.network.api.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
